// ESLint v9 flat config for Siebel CRM IP23 Open UI customizations.
// File: eslint.config.js
//
// Install:
// npm i -D eslint @eslint/js globals @eslint/compat eslint-plugin-jquery eslint-plugin-sonarjs
//
// Notes:
// - ESLint v9 uses flat config by default.
// - eslint-plugin-jquery 1.5.1 is an older plugin. @eslint/compat is used so
//   its rules can operate under the ESLint v9 rule API.
// - SonarJS is enabled using its ESLint 9 recommended configuration.
// - The rules below deliberately tolerate legacy Siebel globals and the
//   prototype/constructor patterns common in PM/PR customizations.

import js from "@eslint/js";
import globals from "globals";
import { fixupPluginRules } from "@eslint/compat";
import jquery from "eslint-plugin-jquery";
import sonarjs from "eslint-plugin-sonarjs";

const jqueryCompat = fixupPluginRules(jquery);

export default [
  {
    ignores: [
      "**/node_modules/**",
      "**/dist/**",
      "**/build/**",
      "**/target/**",
      "**/scripts/siebel/**",
      "**/*.min.js",
      "**/*.bundle.js",
      "**/generated/**",
      "**/vendor/**",
    ],
  },

  js.configs.recommended,

  {
    files: [
      "**/*.js",
      "**/*.mjs",
      "**/*.cjs",
      "**/*PM.js",
      "**/*PModel.js",
      "**/*PR.js",
      "**/*Renderer.js",
    ],

    languageOptions: {
      ecmaVersion: 2021,
      sourceType: "script",
      globals: {
        ...globals.browser,

        // Siebel Open UI runtime globals
        SiebelApp: "readonly",
        SiebelJS: "readonly",
        SiebelJSNamespace: "readonly",
        SiebelAppFacade: "readonly",
        SiebelConstants: "readonly",
        SiebelCfg: "readonly",
        PresentationModel: "readonly",
        PhysicalRenderer: "readonly",

        // jQuery supplied by the Open UI runtime
        $: "readonly",
        jQuery: "readonly",

        // Common legacy browser/Siebel globals
        ActiveXObject: "readonly",
        console: "readonly",
      },
    },

    plugins: {
      jquery: jqueryCompat,
      sonarjs,
    },

    rules: {
      // ------------------------------------------------------------------
      // Core JavaScript quality rules
      // ------------------------------------------------------------------
      "no-undef": "error",
      "no-unused-vars": [
        "warn",
        {
          args: "after-used",
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrors: "none",
        },
      ],
      "no-redeclare": "error",
      "no-dupe-keys": "error",
      "no-unreachable": "error",
      "no-constant-condition": ["error", { checkLoops: false }],
      "no-debugger": "warn",
      "no-alert": "warn",
      "no-eval": "error",
      "no-implied-eval": "error",
      "no-new-func": "error",
      "no-with": "error",
      "no-caller": "error",
      "no-extend-native": "error",

      // Safer object/property handling for legacy Siebel objects.
      "no-prototype-builtins": "error",
      "guard-for-in": "warn",
      "no-proto": "error",

      // ------------------------------------------------------------------
      // Functions / callbacks frequently used by PM/PR code
      // ------------------------------------------------------------------
      "consistent-return": "warn",
      "no-return-await": "error",
      "no-extra-bind": "error",
      "no-unmodified-loop-condition": "warn",
      "no-loop-func": "warn",

      // ------------------------------------------------------------------
      // Style/readability without forcing a modern ES module style on IP23
      // ------------------------------------------------------------------
      "curly": ["error", "multi-line"],
      "eqeqeq": ["error", "always"],
      "no-var": "warn",
      "prefer-const": "warn",
      "no-trailing-spaces": "error",
      "no-multiple-empty-lines": ["error", { max: 1 }],
      "comma-dangle": ["error", "never"],
      "semi": ["error", "always"],
      "quotes": ["error", "double", { avoidEscape: true }],
      "object-shorthand": ["warn", "always"],
      "no-multi-spaces": "error",
      "keyword-spacing": "error",
      "space-before-function-paren": [
        "error",
        { anonymous: "always", named: "never", asyncArrow: "always" },
      ],

      // ------------------------------------------------------------------
      // PM/PR-specific maintainability guardrails
      // ------------------------------------------------------------------
      "max-depth": ["warn", 5],
      "max-nested-callbacks": ["warn", 4],
      "complexity": ["warn", 15],
      "max-statements-per-line": ["error", { max: 1 }],
      "no-inner-declarations": "error",

      // Discourage accidental writes to runtime framework objects.
      "no-global-assign": "error",

      // Prefer explicit property access; bracket notation is still allowed
      // because Siebel metadata often uses dynamic property names.
      "dot-notation": ["warn", { allowKeywords: true }],

      // ------------------------------------------------------------------
      // jQuery rules
      //
      // These are especially useful in Open UI because legacy PM/PR code
      // frequently manipulates DOM elements with jQuery.
      // ------------------------------------------------------------------
      "jquery/no-ajax": "warn",
      "jquery/no-ajax-events": "warn",
      "jquery/no-animate": "warn",
      "jquery/no-attr": "warn",
      "jquery/no-bind": "error",
      "jquery/no-class": "warn",
      "jquery/no-clone": "warn",
      "jquery/no-closest": "warn",
      "jquery/no-css": "warn",
      "jquery/no-data": "warn",
      "jquery/no-deferred": "warn",
      "jquery/no-delegate": "error",
      "jquery/no-each": "warn",
      "jquery/no-fade": "warn",
      "jquery/no-filter": "warn",
      "jquery/no-find": "warn",
      "jquery/no-global-eval": "error",
      "jquery/no-has": "warn",
      "jquery/no-hide": "warn",
      "jquery/no-html": "warn",
      "jquery/no-in-array": "warn",
      "jquery/no-is": "warn",
      "jquery/no-map": "warn",
      "jquery/no-param": "warn",
      "jquery/no-parent": "warn",
      "jquery/no-parents": "warn",
      "jquery/no-parse-html": "warn",
      "jquery/no-prop": "warn",
      "jquery/no-proxy": "warn",
      "jquery/no-serialize": "warn",
      "jquery/no-show": "warn",
      "jquery/no-sizzle": "warn",
      "jquery/no-slide": "warn",
      "jquery/no-text": "warn",
      "jquery/no-toggle": "warn",
      "jquery/no-trigger": "warn",
      "jquery/no-trim": "warn",
      "jquery/no-val": "warn",
      "jquery/no-wrap": "warn",

      // ------------------------------------------------------------------
      // SonarJS rules
      //
      // The recommended SonarJS config is enabled separately below; these
      // explicit rules are kept as high-value checks for PM/PR code.
      // ------------------------------------------------------------------
      "sonarjs/cognitive-complexity": ["warn", 15],
      "sonarjs/no-duplicate-string": ["warn", 5],
      "sonarjs/no-identical-functions": "warn",
      "sonarjs/no-inverted-boolean-check": "warn",
      "sonarjs/no-redundant-boolean": "warn",
      "sonarjs/no-small-switch": "warn",
      "sonarjs/no-unreachable": "error",
      "sonarjs/no-unused-vars": "warn",
    },
  },

  // SonarJS's current ESLint-9 recommended profile.
  sonarjs.configs.recommended,
];
