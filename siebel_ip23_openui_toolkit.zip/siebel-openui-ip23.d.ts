/**
 * Siebel Open UI IP23 ambient TypeScript declarations
 *
 * Target: Siebel CRM IP23 / Open UI custom Presentation Models (PM)
 * and Physical Renderers (PR).
 *
 * These are intentionally ambient/structural declarations: Siebel loads the
 * framework classes at runtime from its own pmodel.js/pr.js infrastructure.
 * They are not a replacement for Oracle's runtime JavaScript.
 *
 * The declarations cover the documented PM/PR lifecycle and common Open UI
 * objects while keeping custom method/property payloads extensible.
 */

declare namespace SiebelOpenUI {
  type AnyFunction = (...args: any[]) => any;
  type Dictionary<T = any> = Record<string, T>;

  interface ReturnStructure {
    CancelOperation?: boolean;
    [key: string]: any;
  }

  interface AddMethodOptions {
    override?: boolean;
    sequence?: boolean;
    [key: string]: any;
  }

  interface PresentationModel {
    Init(...args: any[]): void;
    Setup(...args: any[]): any;

    AddProperty<T = any>(
      propertyName: string,
      propertyValue: T | (() => T)
    ): boolean;

    Get<T = any>(propertyName: string): T;

    SetProperty<T = any>(propertyName: string, value: T): void;

    AddMethod(
      methodName: string,
      method: AnyFunction,
      options?: AddMethodOptions
    ): boolean;

    ExecuteMethod<T = any>(
      methodName: string,
      ...args: any[]
    ): T | undefined;

    AttachEventHandler(
      eventName: string,
      handler: AnyFunction
    ): void;

    AttachNotificationHandler(
      eventName: string,
      handler: AnyFunction
    ): void;

    AttachPMBinding(
      methodName: string,
      handler: AnyFunction
    ): void;

    AttachPostProxyExecuteBinding(
      methodName: string,
      handler: AnyFunction
    ): void;

    AttachPreProxyExecuteBinding(
      methodName: string,
      handler: AnyFunction
    ): void;

    AddComponentCommunication(
      methodName: string,
      targetMethod: string
    ): void;

    AddLocalString(key: string, value: string): any;

    AddValidator(
      propertyName: string,
      validator: AnyFunction
    ): any;

    OnControlEvent(
      eventName: string,
      ...args: any[]
    ): any;

    GetCtrlTemplate?(
      controlName: string,
      displayName: string,
      controlType: any,
      columnIndex: number
    ): any;

    [key: string]: any;
  }

  interface PhysicalRenderer {
    Init(...args: any[]): void;
    ShowUI(...args: any[]): void;
    BindEvents(...args: any[]): void;
    BindData(...args: any[]): void;

    EndLife?(): void;
    Bind?(): void;
    Unbind?(): void;

    GetPM<T extends PresentationModel = PresentationModel>(): T;
    GetProxy<T = any>(): T;
    GetRenderer<T = any>(): T;
    GetContainer?(): JQuery | HTMLElement | null;

    ExecuteMethod<T = any>(
      methodName: string,
      ...args: any[]
    ): T | undefined;

    AttachPMBinding(
      methodName: string,
      handler: AnyFunction
    ): void;

    GetPhysicalControlValue?<T = any>(control: any): T;
    SetControlValue?(control: any, value: any): void;

    [key: string]: any;
  }

  interface Control {
    GetName?(): string;
    GetFieldName?(): string;
    GetUIType?(): string;
    GetInputName?(): string;
    GetProperty?(name: string): any;
    SetProperty?(name: string, value: any): void;
    GetInputElement?(): HTMLElement | null;
    [key: string]: any;
  }

  interface AppletProxy {
    GetControls?(): Dictionary<Control>;
    GetBusComp?(): any;
    InvokeMethod?(methodName: string, ...args: any[]): any;
    GetProperty?(name: string): any;
    SetProperty?(name: string, value: any): any;
    [key: string]: any;
  }

  interface Application {
    GetActiveView?(): any;
    GetActiveApplet?(): any;
    GetProfileAttr?(name: string): any;
    SetProfileAttr?(name: string, value: any): any;
    GetService?(name: string): any;
    [key: string]: any;
  }

  interface SiebelApp {
    S_App?: Application;
    [key: string]: any;
  }
}

/**
 * Base constructors exposed by the Siebel Open UI runtime.
 *
 * In custom code you normally derive from these with SiebelJS.Extend().
 */
declare class PresentationModel implements SiebelOpenUI.PresentationModel {
  Init(...args: any[]): void;
  Setup(...args: any[]): any;
  AddProperty<T = any>(propertyName: string, propertyValue: T | (() => T)): boolean;
  Get<T = any>(propertyName: string): T;
  SetProperty<T = any>(propertyName: string, value: T): void;
  AddMethod(methodName: string, method: SiebelOpenUI.AnyFunction, options?: SiebelOpenUI.AddMethodOptions): boolean;
  ExecuteMethod<T = any>(methodName: string, ...args: any[]): T | undefined;
  AttachEventHandler(eventName: string, handler: SiebelOpenUI.AnyFunction): void;
  AttachNotificationHandler(eventName: string, handler: SiebelOpenUI.AnyFunction): void;
  AttachPMBinding(methodName: string, handler: SiebelOpenUI.AnyFunction): void;
  AttachPostProxyExecuteBinding(methodName: string, handler: SiebelOpenUI.AnyFunction): void;
  AttachPreProxyExecuteBinding(methodName: string, handler: SiebelOpenUI.AnyFunction): void;
  AddComponentCommunication(methodName: string, targetMethod: string): void;
  AddLocalString(key: string, value: string): any;
  AddValidator(propertyName: string, validator: SiebelOpenUI.AnyFunction): any;
  OnControlEvent(eventName: string, ...args: any[]): any;
  GetCtrlTemplate?(controlName: string, displayName: string, controlType: any, columnIndex: number): any;
  [key: string]: any;
}

declare class PhysicalRenderer implements SiebelOpenUI.PhysicalRenderer {
  Init(...args: any[]): void;
  ShowUI(...args: any[]): void;
  BindEvents(...args: any[]): void;
  BindData(...args: any[]): void;
  EndLife?(): void;
  GetPM<T extends SiebelOpenUI.PresentationModel = SiebelOpenUI.PresentationModel>(): T;
  GetProxy<T = any>(): T;
  GetRenderer<T = any>(): T;
  GetContainer?(): JQuery | HTMLElement | null;
  ExecuteMethod<T = any>(methodName: string, ...args: any[]): T | undefined;
  AttachPMBinding(methodName: string, handler: SiebelOpenUI.AnyFunction): void;
  GetPhysicalControlValue?<T = any>(control: any): T;
  SetControlValue?(control: any, value: any): void;
  [key: string]: any;
}

/** Common global Open UI objects used by custom PM/PR files. */
declare const SiebelApp: SiebelOpenUI.SiebelApp;
declare const SiebelJS: {
  Extend<T extends Function, B extends Function>(
    child: T,
    base: B
  ): T;
  [key: string]: any;
};
declare const SiebelJSNamespace: any;
declare const SiebelAppFacade: any;
declare const SiebelConstants: any;
declare const SiebelCfg: any;
declare const $: JQueryStatic;

/**
 * jQuery globals. Prefer importing @types/jquery in projects where possible;
 * these declarations keep legacy Siebel PM/PR source files type-checkable.
 */
declare interface JQueryStatic {
  (selector?: string | Element | Document | Window | Node | any, context?: any): JQuery;
  ajax(settings: JQueryAjaxSettings): JQueryXHR;
  ajax(url: string, settings?: JQueryAjaxSettings): JQueryXHR;
  get(url: string, data?: any, success?: Function, dataType?: string): JQueryXHR;
  post(url: string, data?: any, success?: Function, dataType?: string): JQueryXHR;
  extend(...objects: any[]): any;
  each(collection: any, callback: (index: number, value: any) => any): any;
  [key: string]: any;
}

declare interface JQuery {
  length: number;
  [index: number]: HTMLElement;
  addClass(className: string): this;
  removeClass(className?: string): this;
  toggleClass(className: string, state?: boolean): this;
  hasClass(className: string): boolean;
  attr(name: string, value?: any): any;
  prop(name: string, value?: any): any;
  val(value?: any): any;
  text(value?: string): any;
  html(value?: string): any;
  append(content: any): this;
  prepend(content: any): this;
  before(content: any): this;
  after(content: any): this;
  empty(): this;
  remove(): this;
  find(selector: string): JQuery;
  closest(selector: string): JQuery;
  parent(selector?: string): JQuery;
  children(selector?: string): JQuery;
  on(events: string, handler: Function): this;
  on(events: string, selector: string, handler: Function): this;
  off(events?: string, selector?: string, handler?: Function): this;
  bind(events: string, handler: Function): this;
  unbind(events?: string, handler?: Function): this;
  click(handler?: Function): this;
  change(handler?: Function): this;
  each(callback: (index: number, element: HTMLElement) => any): this;
  data(key?: string, value?: any): any;
  css(property: string, value?: any): any;
  show(): this;
  hide(): this;
  [key: string]: any;
}

declare interface JQueryAjaxSettings {
  url?: string;
  type?: string;
  method?: string;
  data?: any;
  dataType?: string;
  contentType?: string;
  success?: Function;
  error?: Function;
  complete?: Function;
  timeout?: number;
  [key: string]: any;
}

declare interface JQueryXHR {
  done(callback: Function): this;
  fail(callback: Function): this;
  always(callback: Function): this;
  abort?(): void;
  [key: string]: any;
}

/**
 * Typical custom PM/PR constructor shapes.
 *
 * Example:
 *   const CustomPM = function(pm) { ... };
 *   SiebelJS.Extend(CustomPM, PresentationModel);
 *
 *   CustomPM.prototype.Init = function() { ... };
 */
declare type SiebelPMConstructor = new (...args: any[]) => SiebelOpenUI.PresentationModel;
declare type SiebelPRConstructor = new (...args: any[]) => SiebelOpenUI.PhysicalRenderer;
