# Siebel IP23 Open UI TypeScript declarations + ESLint 9

Files:

- `siebel-openui-ip23.d.ts` — ambient declarations for common Siebel Open UI PM/PR APIs.
- `eslint.config.js` — ESLint v9 flat configuration tuned for Siebel Open UI custom JavaScript.
- `package.json` — development dependencies and lint scripts.

## Install

```bash
npm install
```

## Lint

```bash
npm run lint
```

## Important compatibility note

Oracle's Open UI runtime is JavaScript and its exact internal object graph can vary by Siebel release and customization. The `.d.ts` file therefore types the documented PM/PR lifecycle and common APIs structurally rather than pretending to be an official Oracle type package.

The ESLint configuration uses ESLint v9 flat config. `eslint-plugin-jquery` is an older package, so the config wraps it with `@eslint/compat`, which is the official ESLint compatibility mechanism for plugins that still use older rule APIs.

If your project has a locally captured IP23 `pmodel.js`, `pr.js`, or custom PM/PR framework files, those can be used to make the declarations substantially more exact.
